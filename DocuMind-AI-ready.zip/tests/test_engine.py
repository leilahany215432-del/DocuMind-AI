from src.document_engine import extract_entities, split_chunks


def test_split_chunks_keeps_source_and_page():
    chunks = split_chunks([("هذا نص مهم. وهذه جملة ثانية.", 2)], "sample.pdf")
    assert chunks
    assert chunks[0].source == "sample.pdf"
    assert chunks[0].page == 2


def test_extract_entities():
    result = extract_entities("راسلونا test@example.com بتاريخ 2026-11-04. الاسم: أحمد علي")
    assert "test@example.com" in result["البريد الإلكتروني"]
    assert "2026-11-04" in result["التواريخ"]
    assert any("أحمد" in name for name in result["أسماء محتملة"])

"""DocuMind AI source package."""
